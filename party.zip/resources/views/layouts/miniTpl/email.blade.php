<div style="text-align: center;">
	<h1>Уважаемый<span style="color: #b14761;"></span></h1>
	<h2><a style="color: #b14761;" href="">Ссылка</a></h2>
</div>
<div style="background: #ffe5e5; width: 100%; min-height: 50px; padding: 5px;">
</div>