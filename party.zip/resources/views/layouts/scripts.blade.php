<script type="text/javascript" src="{{ asset('/js/jquery-3.1.1.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('/js/app.js') }}"></script>