</div>
<!-- /CONTENT -->
<div class="clear"></div>
<footer class="full-wrapper main-background">
	<div class="wrapper">
		<div class="container">
			<div class="col-4"></div>
			<div class="col-4 center-child">
				<button class="button button-footer"><a href="{{ route('cooperation') }}">СОТРУДНИЧЕСТВО</a></button>
				<button class="button button-footer">ПРАВИЛА</button>
			</div>
			<div class="col-4"></div>
		</div>
		<div class="container">
			<div class="col-4"></div>
			<div class="col-4">
				<div class="container">
					<div class="col-4 center-child">VK</div>
					<div class="col-4 center-child">FB</div>
					<div class="col-4 center-child">DNO</div>
				</div>
			</div>
			<div class="col-4"></div>
		</div>
		<div id="main-notice">
			<div class="container">
				<div class="col-2 notice-char">!</div>
				<div class="col-8 notice-message"></div>
				<div class="col-2 notice-x"></div>
			</div>
		</div>
	</div>
</footer>