<?php $__env->startSection('title'); ?>
	Login
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<p><?php echo e($error); ?></p>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php if(Session::has('message')): ?>
	<p><?php echo e(Session::get('message')); ?></p>
<?php endif; ?>

<!-- <form action="<?php echo e(route('login')); ?>" method="POST">
	<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
	<input type="text" name="email" placeholder="Email">
	<input type="password" name="password" placeholder="Пароль">
	<input type="submit" value="Go">
</form> -->

<form class="form" action="<?php echo e(route('login')); ?>" method="POST">
	<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
	<div class="container">
		<div class="col-6">
			<div class="form-group required">
				<input type="text" name="email" placeholder="Email">
			</div>
			<div class="form-group required">
				<input type="password" name="password" placeholder="Пароль">
			</div>
			<div class="form-group required">
				<button type="submit" class="button create-button">Войти</button>
			</div>
		</div>
	</div>
</form>
<?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.foot', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
