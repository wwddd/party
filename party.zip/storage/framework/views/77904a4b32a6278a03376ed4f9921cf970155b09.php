<?php $__env->startSection('title'); ?>
	Index page
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="full-wrapper">
	<div class="wrapper">
		<div class="container">
			<div class="col-2"></div>
			<div class="col-8">
				<div class="container">
					<div class="col-6 center-child">
						<button>ВПИСАТЬСЯ</button>
					</div>
					<div class="col-6 center-child">
						<button>СОЗДАТЬ</button>
					</div>
				</div>
			</div>
			<div class="col-2"></div>
		</div>
		<div class="clear"></div>
	</div>
</div>

<?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.foot', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>