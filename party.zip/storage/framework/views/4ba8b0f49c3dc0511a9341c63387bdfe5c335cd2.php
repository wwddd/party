<?php $__env->startSection('title'); ?>
	Event page
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="container events">
	<?php $__currentLoopData = $event; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div class="event">

		<?php $title = (strlen($event->title) > 20) ? substr($event->title,0,20).'...' : $event->title; ?>
		<div class=" event-title"><?php echo e($event->title); ?></div>

		<?php if($event->tags !== NULL) { ?>
			<div class="event-inline">
				<div class="event-note">Условия входа: </div>
				<?php echo e($event->tags); ?>

			</div>
		<?php } ?>

		<?php $description = (strlen($event->description) > 360) ? substr($event->description,0,360).'...' : $event->description; ?>
		<div class="event-inline">
			<div class="event-note">Описание: </div>
			<?php echo e($description); ?>

		</div>

		<div class="event-inline">
			<div class="event-place">
				<div class="event-note">Место: </div>
				<?php echo e($event->country); ?>, <?php echo e($event->city); ?>, <?php echo e($event->place); ?> 
			</div>
			<br>
			<div class="event-time">
				<div class="event-note">Время: </div>
				<?php echo e(gmdate("d M H:i, l", $event->start)); ?>

			</div>

			<?php
				$max_peoples = '';
				if($event->peoples_count !== NULL) {
					$max_peoples = ' из ' . $max_peoples;
				}
			?>
			<br>
			<div class="event-currentpeoples">
				<div class="event-note">Максимальное кол-во гостей: </div>
				<?php echo e($event->peoples_count); ?>

			</div>
		</div>

		<div class="event-inline">
			<div class="event-note">Контакт для связи: </div>
			<?php echo e($event->contact); ?>

		</div>

		<?php $__currentLoopData = $owner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $owner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="event-inline">
				<div class="event-note">О пользователе: </div>
				<?php echo e($owner->name); ?> (<?php echo e($owner->age); ?> лет) 
			</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		<?php if(!Auth::user()): ?>
			<p>Для участия во встрече необсходимо <a href="<?php echo e(route('index_login')); ?>">войти</a> или <a href="<?php echo e(route('index_register')); ?>">зарегистрироваться</a></p>
		<?php elseif($owner->name == $current_user->name): ?>
			<div class="event-inline">
				<form class="form" action="<?php echo e(route('event_complete', ['event_id' => $event->id])); ?>" method="POST">
					<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
					<button type="submit" class="button">Завершить</button>
				</form>			
			</div>

			<div class="event-inline">
				<form class="form" action="<?php echo e(route('event_close', ['event_id' => $event->id])); ?>" method="POST">
					<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
					<div class="form-group required">
						<textarea type="text" name="reason" placeholder="Причина закрытия"></textarea>
					</div>
				<div class="form-group">
					<button type="submit" class="button">Закрыть</button>
				</div>
				</form>			
			</div>
		<?php elseif(empty($event_follower[0]->id) == false && empty($event_to_favorites[0]->id) == true): ?>
			<div class="event-inline">
				<form class="form" action="<?php echo e(route('event_un_subscribe', ['event_id' => $event->id, 'follower_id' => $event_follower[0]->follower_id])); ?>" method="POST">
					<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
					<button type="submit" class="button">Отписаться</button>
				</form>			
			</div>
			
			<div class="event-inline">
				<form class="form" action="" method="POST">
					<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
					<button type="submit" class="button">В закладки</button>
				</form>			
			</div>
		<?php elseif(empty($event_follower[0]->id) == true && empty($event_to_favorites[0]->id) == false): ?>)
			<div class="event-inline">
				<form class="form" action="<?php echo e(route('event_subscribe', ['event_id' => $event->id, 'follower_id' => $current_user->id])); ?>" method="POST">
					<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
					<button type="submit" class="button">Вписаться</button>
				</form>			
			</div>
			
			<div class="event-inline">
				<form class="form" action="<?php echo e(route('event_un_favorites')); ?>" method="POST">
					<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
					<button type="submit" class="button">Убрать из закладок</button>
				</form>			
			</div>
		<?php elseif(empty($event_follower[0]->id) == false && empty($event_to_favorites[0]->id) == false): ?>
			<div class="event-inline">
				<form class="form" action="<?php echo e(route('event_un_subscribe', ['event_id' => $event->id, 'follower_id' => $event_follower[0]->follower_id])); ?>" method="POST">
					<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
					<button type="submit" class="button">Отписаться</button>
				</form>			
			</div>
			
			<div class="event-inline">
				<form class="form" action="<?php echo e(route('event_un_favorites', ['user_id' => $current_user->id, 'event_id' => $event->id])); ?>" method="POST">
					<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
					<button type="submit" class="button">Убрать из закладок</button>
				</form>			
			</div>
		<?php else: ?>
			<div class="event-inline">
				<form class="form" action="<?php echo e(route('event_subscribe', ['event_id' => $event->id, 'follower_id' => $current_user->id])); ?>" method="POST">
					<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
					<button type="submit" class="button">Вписаться</button>
				</form>			
			</div>
			
			<div class="event-inline">
				<form class="form" action="<?php echo e(route('to_favorites', ['user_id' => $current_user->id, 'event_id' => $event->id])); ?>" method="POST">
					<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
					<button type="submit" class="button">В закладки</button>
				</form>			
			</div>			
		<?php endif; ?>
	</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.foot', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>