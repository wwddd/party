<?php $__currentLoopData = $ads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div class="adve">
		<a href="<?php echo e($ad->link); ?>" target="_blank">
			<div class="adve-img">
				<img src="<?php echo e($ad->image); ?>">
			</div>
			<div class="adve-title">
				<span><?php echo e($ad->title); ?></span>
			</div>
		</a>
	</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>