<?php $__env->startSection('title'); ?>
	Account page
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="full-wrapper">
	<div class="wrapper">
		<div id="account_tabs">
			<div class="container">
				<div class="col-2 tab" id="create" data-url="<?php echo e(route('ajax-create')); ?>">Создать</div>
				<div class="col-2 tab" id="opened" data-url="<?php echo e(route('ajax-opened')); ?>">Открытые</div>
				<div class="col-2 tab" id="closed" data-url="<?php echo e(route('ajax-closed')); ?>">Завершенные</div>
				<div class="col-2 tab" id="favourite" data-url="<?php echo e(route('ajax-favourite')); ?>">Избранное</div>
				<div class="col-2 tab" id="achievements" data-url="<?php echo e(route('ajax-achievements')); ?>">Мои достижения</div>
				<div class="col-2 tab" id="personal" data-url="<?php echo e(route('ajax-personal')); ?>">Личные данные</div>
			</div>
			<div class="clear"></div>
			<?php if(Session::has('message')): ?>
				<p class="temporary-message"><?php echo e(Session::get('message')); ?></p>
			<?php endif; ?>
			<div class="afterload-tabs" data-id="create"></div>
			<div class="afterload-tabs" data-id="opened"></div>
			<div class="afterload-tabs" data-id="closed"></div>
			<div class="afterload-tabs" data-id="favourite"></div>
			<div class="afterload-tabs" data-id="achievements"></div>
			<div class="afterload-tabs" data-id="personal"></div>
		</div>
	</div>
</div>

<?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/jquery.datetimepicker.css')); ?>"/>
<script src="<?php echo e(asset('/js/jquery.datetimepicker.full.min.js')); ?>"></script>
<?php echo $__env->make('layouts.foot', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>