<?php $__env->startSection('title'); ?>
	Cooperation
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div class="container">
		<p><?php echo e($error); ?></p>
	</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php if(Session::has('message')): ?>
	<div class="container">
		<p><?php echo e(Session::get('message')); ?></p>
	</div>
<?php endif; ?>
	
<div class="full-wrapper">
	<div class="wrapper">
	<div id="cooperation_tabs">		
		<div class="container">
			<div class="col-6 tab" id="membership" data-url="<?php echo e(route('membership')); ?>">Членство</div>
			<div class="col-6 tab active" id="ads" data-url="<?php echo e(route('ads')); ?>">Реклама</div>
		</div>
		
		<div class="clear"></div>
		<div class="afterload-tabs" data-id="membership"></div>
		<div class="afterload-tabs" data-id="ads"></div>
	</div>
	</div>	
</div>

<?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.foot', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
