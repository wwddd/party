<form class="form" action="<?php echo e(route('user_update')); ?>" method="PUT">
	<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
	<!-- <input type="hidden" value="put"> -->
	<div class="container">
		<div class="col-6">
			<div class="form-group">
				<input type="text" name="name" placeholder="Имя" value="<?php echo e($user->name); ?>">
			</div>
			<div class="form-group">
				<input type="number" name="age" min="15" max="90" placeholder="Возраст" value="<?php echo e($user->age); ?>">
			</div>
			<div class="form-group">
				<input type="text" name="contact" placeholder="Skype, телефон, messeger" value="<?php echo e($user->contact); ?>">
			</div>
		</div>
		<div class="col-6">
			<div class="form-group">
				<input type="text" name="country" placeholder="Страна" value="<?php echo e($user->country); ?>">
			</div>
			<div class="form-group">
				<input type="text" name="city" placeholder="Город" value="<?php echo e($user->city); ?>">
			</div>
			<div class="form-group">
				<input type="password" name="password" placeholder="Новый пароль">
			</div>
			<div class="form-group">
				<button type="submit" class="button create-button no-disabled">Сохранить</button>
			</div>
		</div>
	</div>
</form>