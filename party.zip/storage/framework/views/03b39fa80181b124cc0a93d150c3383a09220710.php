<?php $__env->startSection('title'); ?>
	Register
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div class="container">
		<p><?php echo e($error); ?></p>
	</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<div class="full-wrapper">
	<div class="wrapper">
	<div id="register_tabs">		
		<div class="container">
			<div class="col-6 tab active" id="user" data-url="<?php echo e(route('user_form')); ?>">Пользователь</div>
			<div class="col-6 tab" id="company" data-url="<?php echo e(route('company_form')); ?>">Компания</div>
		</div>
		
		<div class="clear"></div>
		<div class="afterload-tabs" data-id="user"></div>
		<div class="afterload-tabs" data-id="company"></div>
	</div>
	</div>	
</div>

<?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.foot', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>