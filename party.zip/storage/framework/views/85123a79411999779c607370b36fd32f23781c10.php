<script type="text/javascript" src="<?php echo e(asset('/js/jquery-3.1.1.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('/js/app.js')); ?>"></script>