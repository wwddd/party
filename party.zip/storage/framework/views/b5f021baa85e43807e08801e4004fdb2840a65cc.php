<!DOCTYPE html>
<html>
<head>
	<title><?php echo $__env->yieldContent('title'); ?></title>
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/style.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('/css/font-awesome/css/font-awesome.min.css')); ?>">
	<meta charset="utf-8">
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
</head>
<body>