<?php $__env->startSection('title'); ?>
	Register
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="full-wrapper">
	<div class="wrapper">
		<div class="container">
			<div class="col-6 tab active">Tab 1</div>
			<div class="col-6 tab">Tab 2</div>
		</div>
		<form action="<?php echo e(route('user_store')); ?>" method="POST">
			<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
			<input type="text" name="name" placeholder="Имя">
			<label>Пол:</label>
			<p><input type="radio" name="gender" value="man">Мужчина</p>
			<p><input type="radio" name="gender" value="woman">Женщина</p>
			<input type="number" name="age" min="15" max="90" placeholder="Возраст">
			<input type="text" name="contact" placeholder="Skype, телефон, messeger">
			<input type="text" name="email" placeholder="email">
			<input type="password" name="password" placeholder="password">
			<input type="checkbox"> C <a href="">правилами</a> согласен
			<input type="button" name="submit" value="go">
		</form>
	</div>	
</div>

<?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.foot', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>