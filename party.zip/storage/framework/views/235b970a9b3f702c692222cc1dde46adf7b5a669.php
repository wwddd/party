<div class="container events">
	<?php if($events->count() == 0): ?>
		<h2 class="title">К сожалению, по запросу ничего не найдено :(</h2>
	<?php endif; ?>
	<?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php echo $__env->make('templates.event', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	<div class="paginate">
		<ul>
			<?php for($i = 1; $i <= $paginate_count; $i++) { ?>
				<li class="<?php $current_page == $i ? print 'active' : ''; ?>" data-page="<?php echo e($i); ?>"><?php echo e($i); ?></li>
			<?php } ?>
		</ul>
	</div>
</div>